#include <iostream>
#include <opencv2/opencv.hpp>

int main() {
    // 打开视频文件，将这里的路径替换为实际的视频文件路径
    cv::VideoCapture video("/home/tjc/Downloads/mofangpeizhi/build/20241026_225827.mp4"); 
    if (!video.isOpened()) {
        std::cerr << "无法打开视频文件" << std::endl;
        return -1;
    }

    // 创建二维码检测器
    cv::QRCodeDetector qrDetector;

    while (true) {
        cv::Mat frame;
        // 读取视频帧
        if (!video.read(frame)) {
            break;
        }

        // 检测和识别二维码
        std::string data = qrDetector.detectAndDecode(frame);
        if (!data.empty()) {
            std::cout << "识别到二维码内容: " << data << std::endl;
            // 可以在这里添加绘制二维码边界框等操作，例如：
            std::vector<cv::Point> points;
            qrDetector.detect(frame, points);
            if (points.size() == 4) {
                for (int i = 0; i < 4; ++i) {
                    cv::line(frame, points[i], points[(i + 1) % 4], cv::Scalar(0, 255, 0), 2);
                }
            }
            cv::imshow("二维码识别结果", frame);
            cv::waitKey(0);
        }

        // 如果需要进行屏幕录制，可以在这里添加相关代码逻辑
        // 例如使用FFmpeg等工具进行屏幕录制，具体实现较为复杂，这里只是提供思路
        // 大致步骤包括：启动FFmpeg进程，将每一帧写入录制文件等操作

        // 显示当前帧（可选）
        cv::imshow("视频", frame);
        if (cv::waitKey(30) == 27) { // 按Esc键退出
            break;
        }
    }

    video.release();
    cv::destroyAllWindows();

    return 0;
}