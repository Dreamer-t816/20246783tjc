import cv2
import numpy as np
import matplotlib.pyplot as plt
import time

# 1. 图像预处理
def preprocess_image(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    return blurred

# 2. 特征点提取
def extract_features(image):
    sift = cv2.SIFT_create()
    keypoints, descriptors = sift.detectAndCompute(image, None)
    return keypoints, descriptors

# 3. 特征点匹配
def match_features(descriptors1, descriptors2):
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(descriptors1, descriptors2, k=2)
    good_matches = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good_matches.append(m)
    return good_matches

# 4. 单应性矩阵计算与图像拼接
def stitch_images(image1, image2, good_matches, keypoints1, keypoints2):
    src_pts = np.float32([keypoints1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([keypoints2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    H, status = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
    h1, w1 = image1.shape[:2]
    h2, w2 = image2.shape[:2]
    result = cv2.warpPerspective(image1, H, (w1 + w2, h1))
    result[0:h2, 0:w2] = image2
    return result

# 读取图片
image1 = cv2.imread('3.jpg')
image2 = cv2.imread('4.jpg')

# 预处理
preprocessed1 = preprocess_image(image1)
preprocessed2 = preprocess_image(image2)

# 提取特征点
keypoints1, descriptors1 = extract_features(preprocessed1)
keypoints2, descriptors2 = extract_features(preprocessed2)

# 在原图上绘制特征点
image1_with_kp = cv2.drawKeypoints(image1, keypoints1, None)
image2_with_kp = cv2.drawKeypoints(image2, keypoints2, None)

# 特征点匹配
good_matches = match_features(descriptors1, descriptors2)

# 图像拼接
result = stitch_images(image1, image2, good_matches, keypoints1, keypoints2)

# 使用matplotlib展示图片
# 展示带有特征点的图片
plt.subplot(131), plt.imshow(cv2.cvtColor(image1_with_kp, cv2.COLOR_BGR2RGB))
plt.title('Image 1 with Keypoints'), plt.xticks([]), plt.yticks([])
plt.subplot(132), plt.imshow(cv2.cvtColor(image2_with_kp, cv2.COLOR_BGR2RGB))
plt.title('Image 2 with Keypoints'), plt.xticks([]), plt.yticks([])
# 展示拼接后的图片
plt.subplot(133), plt.imshow(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
plt.title('Stitched Image'), plt.xticks([]), plt.yticks([])
plt.show()

# 计算帧率
start_time = time.time()
end_time = time.time()
processing_time = end_time - start_time
fps = 1 / processing_time
print(f"Processing Time: {processing_time} seconds")
print(f"Frames per Second: {fps}")