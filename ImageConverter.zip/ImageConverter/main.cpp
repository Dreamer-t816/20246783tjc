#include <iostream>
#include <fstream>
#include <chrono>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
void RGBToNV12(unsigned char* rgb, unsigned char*& nv12, int width, int height) {
    int yPlaneSize = width * height;
    int uvPlaneSize = (width / 2) * (height / 2);
    
    nv12 = new unsigned char[yPlaneSize + uvPlaneSize];

    unsigned char* yPlane = nv12;
    unsigned char* uvPlane = nv12 + yPlaneSize;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int r = rgb[(y * width + x) * 3 + 0];
            int g = rgb[(y * width + x) * 3 + 1];
            int b = rgb[(y * width + x) * 3 + 2];

            // Y' = 0.299R + 0.587G + 0.114B
            int yValue = (int)(0.299 * r + 0.587 * g + 0.114 * b);
            yPlane[y * width + x] = static_cast<unsigned char>(yValue);

            if (x % 2 == 0 && y % 2 == 0) {
                // U' = -0.147R - 0.289G + 0.436B
                // V' = 0.615R - 0.515G - 0.100B
                int uValue = (int)(-0.147 * r - 0.289 * g + 0.436 * b);
                int vValue = (int)(0.615 * r - 0.515 * g - 0.100 * b);
                
                // Store U and V plane
                uvPlane[(y/2) * (width/2) + (x/2) * 2] = static_cast<unsigned char>(uValue + 128); // U
                uvPlane[(y/2) * (width/2) + (x/2) * 2 + 1] = static_cast<unsigned char>(vValue + 128); // V
            }
        }
    }
}

unsigned char* NV12ToRGB(unsigned char* nv12, int width, int height) {
    unsigned char* rgb = new unsigned char[width * height * 3];
    
    unsigned char* yPlane = nv12;
    unsigned char* uvPlane = nv12 + (width * height);

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int yValue = yPlane[y * width + x];
            int uValue, vValue;

            if (x % 2 == 0 && y % 2 == 0) {
                uValue = uvPlane[(y / 2) * (width / 2) + (x / 2) * 2] - 128; // Get U
                vValue = uvPlane[(y / 2) * (width / 2) + (x / 2) * 2 + 1] - 128; // Get V
            }

            // Calculate RGB from YUV
            int r = (yValue + 1.402 * vValue);
            int g = (yValue - 0.344136 * uValue - 0.714136 * vValue);
            int b = (yValue + 1.772 * uValue);

            rgb[(y * width + x) * 3 + 0] = std::min(std::max(r, 0), 255);
            rgb[(y * width + x) * 3 + 1] = std::min(std::max(g, 0), 255);
            rgb[(y * width + x) * 3 + 2] = std::min(std::max(b, 0), 255);
        }
    }

    return rgb;
}

int main() {
    int width, height, channels;
    unsigned char* rgb = stbi_load("test1.jpg", &width, &height, &channels, 3);

    if (rgb == nullptr) {
        std::cerr << "Failed to load image" << std::endl;
        return -1;
    }

    unsigned char* nv12;
    auto start = std::chrono::high_resolution_clock::now();
    RGBToNV12(rgb, nv12, width, height);
    auto end = std::chrono::high_resolution_clock::now();
    double conversionTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    double fps = 1000.0 / conversionTime;

    std::ofstream nv12File("test1_nv12.yuv", std::ios::binary);
    nv12File.write(reinterpret_cast<char*>(nv12), width * height + (width / 2) * (height / 2));
    nv12File.close();

    unsigned char* reconstructedRgb = NV12ToRGB(nv12, width, height);
    stbi_write_jpg("test1_reconstructed.jpg", width, height, 3, reconstructedRgb, 100);
    
    std::cout << "Conversion time: " << conversionTime << " ms, FPS: " << fps << std::endl;

    delete[] rgb;
    delete[] nv12;
    delete[] reconstructedRgb;

    return 0;
}